import math
from abc import ABCMeta, abstractmethod
import numpy as np
import tf
from myicp import ICP_node

M_DIST_TH = 0.6  
STATE_SIZE = 3  
LM_SIZE = 2
Q = np.diag([
    0.2,  # variance of location on x-axis
    0.2,  # variance of location on y-axis
    math.radians(3.0)  # variance of yaw angle
]) ** 2  # predict state covariance
R = np.diag([0.2, 0.2,math.radians(3.0)]) ** 2  # Observation x,y position covariance

class EKF(object):
    __metaclass__ = ABCMeta
    def __init__(self):
        pass
    def estimate(self, xEst, PEst, z, u):
        G,Fx=self.jacob_motion(xEst,u)
        covariance=np.dot(G.T,np.dot(PEst,G))+np.dot(Fx.T,np.dot(Q,Fx))  
        # Predict
        xPredict=self.odom_model(xEst,u)
        zEst=self.observation_model(xPredict)
        m=self.jacob_h()
        # Karman factor. Universal formula.
        K=np.dot(np.dot(covariance,m.T),np.linalg.inv(np.dot(m,np.dot(covariance,m.T))+R))
        # Update
        xEst=xPredict+np.dot(K,z-zEst)
        PEst=covariance-np.dot(K,np.dot(m,covariance))
        return xEst, PEst

    def odom_model(self, x, u):
        return x+u

    def jacob_motion(self, x, u):
        G=np.identity(3)
        Fx=np.identity(3)
        return (G,Fx)

    @abstractmethod # virtual.
    def observation_model(self,x):
        return x

    def jacob_h(self):
        '''
        the Jacobian of observation model.
        '''
        return np.identity(3)

class EKF_Node(EKF):
    # EKF state covariance
    Cx = np.diag([0.35, 0.35, np.deg2rad(15.0)]) ** 2
    def __init__(self):
        super(EKF_Landmark,self).__init__()
    def jacob_h(self, tar, neighbour, x):
        length=len(neighbour.tar_indices)
        if length==0:
            print("Error: no points were matched!")
            return 0
        rotation=tf.transformations.euler_matrix(0,0,x[2,0])[0:2,0:2]
        # the yaw(theta) derivative of rotation. [[-sin,cos],[-cos,-sin]]
        derivativeR=tf.transformations.euler_matrix(0,0,x[2,0]+math.pi/2)[0:2,0:2]
        z=tar[:,neighbour.tar_indices]
        partialTheta=np.dot(np.transpose(derivativeR),z-x[0:2,0].reshape(2,1))
        partialTheta=np.vstack(np.hsplit(partialTheta,length))
        H=np.repeat(-np.transpose(rotation),length,axis=0)
        H=np.hstack((H,partialTheta))
        return H
    def calc_landmark_position(self, x, z):
        zp = np.zeros((2, 1))
        zp[0, 0] = x[0, 0] + z[0] * math.cos(x[2, 0] + z[1])
        zp[1, 0] = x[1, 0] + z[0] * math.sin(x[2, 0] + z[1])
        return zp
    def calc_n_lm(self, x):
        n = int((len(x) - STATE_SIZE) / LM_SIZE)
        return n
    def get_landmark_position_from_state(self, x, ind):
        lm = x[STATE_SIZE + LM_SIZE * ind: STATE_SIZE + LM_SIZE * (ind + 1), :]
        return lm
    def search_correspond_landmark_id(self, xAug, PAug, zi):
        nLM = self.calc_n_lm(xAug)
        min_dist = []
        ## TODO search and update min_dist
        min_dist.append(M_DIST_TH)  # new landmark
        min_id = min_dist.index(min(min_dist))
        return min_id
    def piRange(self, angle):
        return (angle + math.pi) % (2 * math.pi) - math.pi

