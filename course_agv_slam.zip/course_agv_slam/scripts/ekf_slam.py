#!/usr/bin/env python
import rospy
import tf
import math
import sys
from std_msgs.msg import Header,ColorRGBA
from geometry_msgs.msg import Point,Quaternion,Vector3
from nav_msgs.srv import GetMap
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry
from visualization_msgs.msg import MarkerArray,Marker
import numpy as np
from myicp import ICP_node,LandmarkICP,Localization,SubICP
from ekf_node import EKF_Node
from extraction import LandMarkSet,Extraction
from mapping import Mapping
from nav_msgs.msg import OccupancyGrid

class SLAM_EKF(Localization,EKF_Node):
    alpha=3.0
    def __init__(self,nodeName="ekf_slam"):
        super(SLAM_EKF,self).__init__(nodeName)
        self.map_x_width = 20
        self.map_y_width = 20
        self.map_reso =0.1
        self.map_cellx_width = int(round(self.map_x_width/self.map_reso))
        self.map_celly_width = int(round(self.map_y_width/self.map_reso))
        self.mapping = Mapping(self.map_cellx_width, self.map_celly_width, self.map_reso)
        self.icp = SubICP()
        self.extraction = Extraction()
        self.icp_node=ICP_node()
        self.src_pc = None
        self.isFirstScan = True
        self.laser_count=0
        self.lm_set=LandMarkSet()
        self.xEst = np.zeros((3,1),dtype=float)
        self.txEst = np.zeros((3,1),dtype=float)
        self.PEst = np.eye(3)
        self.tar_lm = None
        self.tar_pc = None
        self.xxx_pc=None
        self.laser_sub = rospy.Subscriber('/course_agv/laser/scan',LaserScan,self.laserCallback)
        self.landMark_pub = rospy.Publisher('/landmarks',MarkerArray,queue_size=3)
        self.tar_pc=self.icp_node.icptar
        self.min_match = int(rospy.get_param('/localization/min_match',2))
        self.extraction.landMark_min_pt = int(rospy.get_param('/localization/landMark_min_pt',2))
        self.extraction.radius_max_th = float(rospy.get_param('/localization/radius_max_th',0.4))
        self.map_pub = rospy.Publisher('/slam_map',OccupancyGrid,queue_size=1)

    
    

    def publishMap(self,pmap):
        map_msg = OccupancyGrid()
        map_msg.header.seq = 1
        map_msg.header.stamp = rospy.Time().now()
        map_msg.header.frame_id = "map"
        map_msg.info.map_load_time = rospy.Time().now()
        map_msg.info.resolution = self.map_reso
        map_msg.info.width = self.map_cellx_width
        map_msg.info.height = self.map_celly_width
        map_msg.info.origin.position.x = -self.map_cellx_width*self.map_reso/2.0
        map_msg.info.origin.position.y = -self.map_celly_width*self.map_reso/2.0
        map_msg.info.origin.position.z = 0
        map_msg.info.origin.orientation.x = 0
        map_msg.info.origin.orientation.y = 0
        map_msg.info.origin.orientation.z = 0
        map_msg.info.origin.orientation.w = 1.0
        map_msg.data = list(pmap.T.reshape(-1))
        map_msg.data  = np.trunc(map_msg.data).astype(np.int8).tolist()       
        self.map_pub.publish(map_msg)

    
    def laserCallback(self,msg):
            
        if(msg.ranges[0]>999 or msg.ranges[3]>999  or msg.ranges[3]<-999  or msg.ranges[0]<-999):
            return 
        if self.isFirstScan:
            self.icp.tar_pc=self.icp.laserToNumpy(msg)
            tmplandmark=self.extraction.process2(msg,True)
            self.lm_src_pc = self.lm2pc(tmplandmark)
            self.AddNewLandmark(msg)
            self.isFirstScan = False
            return
        

        self.laser_count += 1
        if self.laser_count < 5:
            return
        # Updating
        self.laser_count = 0
        landmarks=self.extraction.process(msg,True)
        tmplandmark=self.extraction.process2(msg,True)
        self.lm_src_pc = self.lm2pc(tmplandmark)
        self.publishLandMark(landmarks,"b")
        u=self.calc_odometry(msg)
        # z is the landmarks as a 2*n array.
        z=landmarks
        self.xEst,self.PEst=self.estimate(self.xEst,self.PEst,z,u)
        
        #print(self.xEst)
        self.AddNewLandmark(msg)
        self.publishResult()
        np_msg = self.laserToNumpy(msg)
        obs = self.u2T(self.xEst[0:3]).dot(np_msg)   
        pmap = self.mapping.update(obs[0], obs[1], self.xEst[0], self.xEst[1])
        self.publishMap(pmap)
        return



    def u2T(self,u):
        w = u[2]
        dx = u[0]
        dy = u[1]

        return np.array([
            [ math.cos(w),-math.sin(w), dx],
            [ math.sin(w), math.cos(w), dy],
            [0,0,1]
        ])

    def T2u(self,t):
        dw = math.atan2(t[1,0],t[0,0])
        u = np.array([[t[0,2],t[1,2],dw]])
        return u.T  # 3*1


    def laserToNumpy(self,msg):
        total_num = len(msg.ranges)
        pc = np.ones([3,total_num])
        range_l = np.array(msg.ranges)
        range_l[range_l==np.inf]=20
        range_l[range_l==np.nan]=20
        angle_l = np.linspace(msg.angle_min,msg.angle_max,total_num)
        pc[0:2,:] = np.vstack((np.multiply(np.cos(angle_l),range_l),np.multiply(np.sin(angle_l),range_l)))
        return pc

    def lm2pc(self,lm):
        total_num = len(lm.position_y)
        dy = lm.position_y
        dx = lm.position_x
        range_l = np.hypot(dy,dx)
        angle_l = np.arctan2(dy,dx)
        pc = np.ones((3,total_num))
        pc[0:2,:] = np.vstack((np.multiply(np.cos(angle_l),range_l),np.multiply(np.sin(angle_l),range_l)))
        ##print("mdbg ",total_num)
        return pc

    def lmtrans(self, lm):
        landmarks = lm
        z = np.zeros((0, 3))
        for i in range(len(landmarks.id)):
            dx = landmarks.position_x[i]
            dy = landmarks.position_y[i]
            d = math.hypot(dx, dy)
            zi = np.array([d, angle])
            z = np.vstack((z, zi))
        return z


    def calc_odometry(self,msg):
        state_old=np.copy(self.icp.xEst)
        self.icp.laserCallback(msg)
        u=self.icp.xEst-state_old
        return u

    def publishLandMark(self,msg,color="b",namespace="laser",frame="course_agv__hokuyo__link"):
        if len(msg) <= 0:
            return
        
        landMark_array = MarkerArray()
        landMark_array.markers=[self.pos2lm(x,i,color,namespace,frame) for i,x in enumerate(msg.T)]
        self.landMark_pub.publish(landMark_array)

    def pos2lm(self,pair,id=0,color="b",namespace="laser",frame="course_agv__hokuyo__link"):
        colorDict={
            "r":[1,0,0,1.0], "R":[1,0,0,1.0],
            "g":[0,1,0,1.0], "G":[0,1,0,1.0],
            "b":[0,0,1,1.0], "B":[0,0,1,1.0],
        }
        marker = Marker(header=Header(id,rospy.Time(0),frame))
        marker.ns = namespace
        marker.id = id
        marker.type = Marker.SPHERE
        marker.action = Marker.ADD
        marker.pose.position=Point(pair[0],pair[1],0)
        marker.pose.orientation=Quaternion(0,0,0,1)
        marker.scale=Vector3(0.2,0.2,0.2)
        marker.color=ColorRGBA(*colorDict[color])
        return marker


    def observation_model(self,xEst):
        
        rotation=tf.transformations.euler_matrix(0,0,xEst[2,0])[0:2,0:2]
        z=np.dot(rotation.T,self.tar_pc-xEst[0:2,0].reshape(2,1))
        return z

    def estimate(self,xEst,PEst,z,u):
        G,Fx=self.jacob_motion(xEst,u)
        covariance=np.dot(G.T,np.dot(PEst,G))+np.dot(Fx.T,np.dot(self.Cx,Fx))
        
        # Predict
        xPredict=self.odom_model(xEst,u)
        zEst=self.observation_model(xPredict)
        neighbour=self.icp.findNearest(z,zEst)
        zPredict=zEst[:,neighbour.tar_indices]
        zPrime=z[:,neighbour.src_indices]
        length=len(neighbour.src_indices)
        variance=self.alpha/(length+self.alpha)
        if length<self.min_match:
            #print("Matching points are not enough.")
            #  no update under this condition.
            return xPredict, covariance

        m=self.jacob_h(self.tar_pc,neighbour,xPredict)
        zPredict=np.vstack(np.hsplit(zPredict,np.size(zPredict,1)))
        zPrime  =np.vstack(np.hsplit(zPrime,np.size(zPrime,1)))
        # K factor
        K=np.dot(np.dot(covariance,m.T),np.linalg.inv(np.dot(m,np.dot(covariance,m.T))+np.diag([variance]*2*length)))
        # update xEst and PEst
        xEst=xPredict+np.dot(K,zPrime-zPredict)
        deltax=np.zeros((3,1))
        PEst=covariance-np.dot(K,np.dot(m,covariance))

        return xEst, PEst


    def findNearest(self,previous_points, current_points):
        
        delta_points = previous_points - current_points
        d = np.linalg.norm(delta_points, axis=0)
        error = sum(d)
        d = np.linalg.norm(np.repeat(current_points, previous_points.shape[1], axis=1)
                        - np.tile(previous_points, (1, current_points.shape[1])), axis=0)
        indexes = np.argmin(d.reshape(current_points.shape[1], previous_points.shape[1]), axis=1)

        return indexes, error


    def AddNewLandmark(self,msg):
        if (len(self.lm_set.position_y)==0):
            tmp_lm=self.u2T(self.xEst[0:3]).dot(self.lm_src_pc)
            for i in range(tmp_lm.shape[1]):
                    self.lm_set.position_x.append(tmp_lm[0][i])
                    self.lm_set.position_y.append(tmp_lm[1][i])
        else:
            tmp_lm=self.u2T(self.xEst[0:3]).dot(self.lm_src_pc)
            for i in range(tmp_lm.shape[1]):
                min_dist=10
                for j in range(len(self.lm_set.position_y)):
                    tmp_dist=math.hypot(tmp_lm[0][i]-self.lm_set.position_x[j],tmp_lm[1][i]-self.lm_set.position_y[j])
                    if tmp_dist<min_dist:
                        min_dist=tmp_dist
                if(min_dist>1.5):
                    self.lm_set.position_x.append(tmp_lm[0][i])
                    self.lm_set.position_y.append(tmp_lm[1][i])
        '''
        for k in range(tmp_lm.shape[1]):
            min_dist=10
            for z in range(self.tar_pc.shape[1]):
                tmp_dist=math.hypot(tmp_lm[0][k]-self.tar_pc[0][z],tmp_lm[1][k]-self.tar_pc.shape[1][z])
                if tmp_dist<min_dist:
                    min_dist=tmp_dist
        if(min_dist<1.5):
        '''    
        self.xEst=self.icp_node.ICPprocess(msg,self.xEst);
        self.tar_lm = np.array([self.lm_set.position_x,self.lm_set.position_y],dtype=float)    


def main():
    rospy.init_node('ekf_slam_node')
    l = SLAM_EKF()
    rospy.spin()
    pass

def test():
    pass

if __name__ == '__main__':
    main()

