#!/usr/bin/env python
from sensor_msgs.msg import LaserScan

import numpy as np
import rospy

class LandMarkSet():
    def __init__(self):
        self.position_x = []
        self.position_y = []
        self.id = []

class Extraction():
    def __init__(self):
        self.range_threshold = float(rospy.get_param('/extraction/range_threshold',1.0))
        self.radius_max_th = float(rospy.get_param('/extraction/radius_max_th',0.3))
        self.landMark_min_pt = int(rospy.get_param('"/extraction/landMark_min_pt',2))

    def process(self,msg,trust = False):
        labels = []
        ranges=np.array(msg.ranges)
        np.append(ranges,ranges[0])
        difference=np.diff(ranges)
        spitpoint=np.nonzero(np.abs(difference)>self.range_threshold)[0]
        np.append(spitpoint,spitpoint[0]+np.size(difference))
        for i in range(np.size(spitpoint)-1):
            points=spitpoint[i+1]-spitpoint[i]
            if points>=self.landMark_min_pt:
                if ranges[spitpoint[i]]*msg.angle_increment*points<=self.radius_max_th*2:
                    labels.append(((spitpoint[i]+spitpoint[i+1]+1)//2)%np.size(difference))
        return self.extractLandMark(msg,labels,trust)



    def process2(self,msg,trust = False):
        labels = []
        ranges=np.array(msg.ranges)
        np.append(ranges,ranges[0])
        difference=np.diff(ranges)
        spitpoint=np.nonzero(np.abs(difference)>self.range_threshold)[0]
        np.append(spitpoint,spitpoint[0]+np.size(difference))
        for i in range(np.size(spitpoint)-1):
            points=spitpoint[i+1]-spitpoint[i]
            if points>=self.landMark_min_pt:
                if ranges[spitpoint[i]]*msg.angle_increment*points<=self.radius_max_th*2:

                    labels.append(((spitpoint[i]+spitpoint[i+1]+1)//2)%np.size(difference))
        return self.extractLandMark2(msg,labels,trust)

    def extractLandMark(self,msg,labels,trust):
        ranges=np.array(msg.ranges)
        theta =np.linspace(msg.angle_min,msg.angle_max,len(msg.ranges))

        ranges=ranges[labels]
        theta =theta[labels]
        landmark=np.vstack((np.multiply(np.cos(theta),ranges),np.multiply(np.sin(theta),ranges)))
        return landmark

    def extractLandMark2(self,msg,labels,trust):

        ranges=np.array(msg.ranges)
        theta =np.linspace(msg.angle_min,msg.angle_max,len(msg.ranges))

        ranges=ranges[labels]
        theta =theta[labels]
        landMarks=LandMarkSet()
        for i in range(0,len(ranges)):        
            landMarks.position_x.append(np.cos(theta[i])*ranges[i])
            landMarks.position_y.append(np.sin(theta[i])*ranges[i])
            landMarks.id.append(i)
        return landMarks

