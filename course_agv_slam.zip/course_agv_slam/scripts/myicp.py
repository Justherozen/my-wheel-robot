#!/usr/bin/env python
import rospy
import tf
from nav_msgs.srv import GetMap
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry
from visualization_msgs.msg import MarkerArray,Marker
from extraction import LandMarkSet,Extraction
import sys
import rospy
import tf
from sensor_msgs.msg import LaserScan,PointCloud
from nav_msgs.msg import Odometry,Path
from nav_msgs.msg import OccupancyGrid
from geometry_msgs.msg import TransformStamped,Point32
from nav_msgs.srv import GetMap
from geometry_msgs.msg import Twist, PointStamped,PoseStamped
from sensor_msgs.msg import ChannelFloat32
import numpy as np
import math
import time
from scipy.spatial import cKDTree as KDTree
import sys
import copy
import random
from mapping import Mapping
from nav_msgs.msg import OccupancyGrid
from geometry_msgs.msg import Pose,Quaternion,Point
from std_msgs.msg import Header
np.set_printoptions(threshold=np.inf)

class NeighBor:

    def __init__(self):

        self.distances = []

        self.src_indices = []

        self.tar_indices = []



class ICP_node:

    def __init__(self): 

        self.tmpposes=[]

        self.icppoints=[]

        self.icppoints2=[]
        self.icppoints3=[]

        self.realpath=Path()

        self.realpath.poses=[]

        self.icpcloud=PointCloud()

        self.icpcloud2=PointCloud()
        self.icpcloud3=PointCloud()

        self.laser_count = 0

        self.obstacle_r = 10

        self.obstacle = []

        self.target_laser=LaserScan()
        self.extraction = Extraction()
        # robot init states

        self.robot_x = rospy.get_param('/icp/robot_x',0)

        self.robot_y = rospy.get_param('/icp/robot_y',0)

        self.robot_theta = rospy.get_param('/icp/robot_theta',0)

        # sensor states = robot_x_y_theta

        self.sensor_sta = [self.robot_x,self.robot_y,self.robot_theta]

        self.H=None

        self.H2=None


        self.H3=None

        # max iterations

        self.max_iter = rospy.get_param('/icp/max_iter',50)

        # distance threshold for filter the matching points

        self.dis_th = rospy.get_param('/icp/dis_th',5)

        # tolerance to stop icp

        self.tolerance = rospy.get_param('/icp/tolerance',0.0001)
        self.tolerance2 =0.0000000000000000001
        # if is the first scan, set as the map/target

        self.isFirstScan = True

        # src point cloud matrix

        self.src_pc = []

        self.ver_pc = []

        self.lm_tar_pc = []

        self.lm_src_pc = []        
        # target point cloud matrix

        self.tar_pc = []
        self.landmarks_tar=LandMarkSet()
        self.landmarks_src=LandMarkSet()

        self.laser_pub = rospy.Publisher('/target_laser',LaserScan,queue_size=3)
        self.map_broadcaster = tf.TransformBroadcaster()
        self.map_broadcaster.sendTransform((0,0,0),tf.transformations.quaternion_from_euler(0, 0,0),time.time(),"world_base","map")
        self.laser_sub = rospy.Subscriber('/map',OccupancyGrid,self.updateMap)
        self.odom_pub = rospy.Publisher('icp_odom_2',Odometry,queue_size=1)
        self.odom_broadcaster = tf.TransformBroadcaster()
        self.odom_broadcaster_2 = tf.TransformBroadcaster()
        self.odom_broadcaster_3 = tf.TransformBroadcaster()
        self.tf = tf.TransformListener()
        self.xEst = np.zeros((3,1),dtype=float)
        self.xEst_lm = np.zeros((3,1))
        self.txEst = np.zeros((3,1))
        self.xdom = np.zeros((3,1))
        self.realpath_pub = rospy.Publisher('realpath',Path,queue_size=1)
        self.location_pub = rospy.Publisher('ekf_location',Odometry,queue_size=1)
        self.location_lm_pub = rospy.Publisher('lm_location',Odometry,queue_size=1)
        self.icpp_pub = rospy.Publisher('ekff',PointCloud,queue_size=1)
        self.icpp_pub2 = rospy.Publisher('icpp',PointCloud,queue_size=1)
        self.icpp_pub3 = rospy.Publisher('lmpp',PointCloud,queue_size=1)
        self.indexi=0
        self.landMark_pub = rospy.Publisher('/landMarks',MarkerArray,queue_size=1)
        self.ekf1_time=0
        self.ekf2_time=0
        self.ekf3_time=0
        self.jishuqi=0
        self.map_x_width = 20
        self.map_y_width = 20
        self.map_reso = 0.1
        self.map_cellx_width = 200
        self.map_celly_width = 200
        self.map_pub = rospy.Publisher('/slam_map',OccupancyGrid,queue_size=1)
        self.mapping = Mapping(self.map_cellx_width,self.map_celly_width,self.map_reso)
        self.allpointx=[0,-1,-2,-3,-4,-5,-6,-7,-8,-7,-7,-7,-6,-5,-4,-3,-2,-1,0,1,2,2,3,3,4,3,3,4,3,2,1,0,-1,-2,-3]
        self.allpointy=[0,0,1,1,0,-1,-1,-2,-3,-4,-5,-6,-7,-7,-7,-7,-7,-7,-7,-6,-5,-4,-3,-2,-1,0,1,2,3,4,3,3,3,2,1]
        self.allpointx2=[5,6,7,8,8,8,7]
        self.allpointy2=[-8,-8,-8,-7,-6,-5,-4]
        self.icptar=[]
        self.mapdata=[]
        self.obstacle_r = 0.155
        self.initialize()

    def initialize(self):
        self.icptar=np.array([[-7.98499998,-7.82999998,-7.82999998,-7.67499998 ,-7.67499998 ,-7.51999998, -6.58999997,-6.12499997,-5.81499997,-5.81499997 ,-5.34999996 ,-5.19499996,-5.03999996,-4.72999996,-3.64499995,-3.17999995 ,-3.02499995 ,-2.24999994,-2.09499994,-1.78499994,-0.54499993,-0.38999993 ,-0.07999992  ,0.54000008, 1.62500009 ,1.78000009 ,1.93500009 ,2.8650001  ,3.1750001 , 3.3300001, 4.10500011 ,4.26000011 ,5.19000012 ,5.19000012 ,5.65500012 , 5.65500012,6.12000012 ,6.12000012 ,6.89500013 ,8.13500014 ,8.29000014  ,8.29000014, 8.29000014],[-4.72999996 ,-0.85499993 , 4.72500011 ,-8.44999999,  2.5550001,  -6.58999997,8.13500014 ,0.54000008 ,-5.65999997 , 2.4000001 ,  4.57000011 ,-7.82999998,  6.58500013 ,-3.33499995 , 1.93500009 , 4.10500011 ,-8.44999999 , 0.54000008,  -3.17999995 ,-6.27999997 ,-4.26499996 , 3.95000011 , 5.34500012 ,-6.89999998, 4.41500011 ,-2.86999995 , 1.93500009 ,-4.57499996 ,-7.98499998 , 4.26000011,   0.07500008 ,-2.09499994 ,2.4000001 ,  5.81000012 ,-8.91499999 ,-3.48999995, -0.69999993  ,7.82500014 ,3.95000011, -0.69999993, -8.29499999 ,-3.17999995,   2.09000009]])

    def get_tar(self,a):
        a=self.icptar

    def ICPprocess(self,msg,xinput):
        if(msg.ranges[0]>999 or msg.ranges[3]>999  or msg.ranges[3]<-999  or msg.ranges[0]<-999):
            return 

        ###print("msg")

        ###print(msg)

        ##print('------seq:  ',msg.header.seq)
        '''

        landmarks_src = self.extraction.process(msg,True)
        landmarks_tar = self.extraction.process(self.laserEstimation(msg,x),True)
        #print("lm : ",len(landmarks_src.id),len(landmarks_tar.id))
        self.publishLandMark(landmarks_src,landmarks_tar)
        #src_pc = self.lm2pc(self.extraction.process(msg,True))
        #tar_pc = self.lm2pc(landmarks_tar)
        #transform_acc = self.icp.process(tar_pc,src_pc)
        #return self.T2u(transform_acc)


        '''
        if self.isFirstScan:
            self.tar_pc = self.laserToNumpy(msg)
            self.target_laser=self.laserEstimation(msg,self.xEst)
            #self.landmarks_tar = self.extraction.process(self.target_laser,True)
            ##print(self.landmarks_tar)
            self.lm_tar_pc = self.lm2pc(self.landmarks_tar)
            self.ver_pc=self.laserToNumpy(self.target_laser)
            self.isFirstScan = False
            self.laser_count = 0          
            return self.xEst

        

        # process every 5 laser scan for laser fps too high

        self.jishuqi=self.jishuqi+1
        self.laser_count = 0
        time_0 = time.time()
        self.src_pc = self.laserToNumpy(msg)
        #self.landmarks_src = self.extraction.process(msg,True)
        #self.lm_src_pc = self.lm2pc(self.landmarks_src)
        ##print('input cnt: ',self.src_pc.shape[1])
        # init some variables
        transform_acc = np.identity(3)
        ekf_acc = np.identity(3)
        lm_acc = np.identity(3)
        m = self.src_pc.shape[1]
        #mysrc = np.ones((m+1,self.src_pc.shape[0]))
        #mydst = np.ones((m+1,self.tar_pc.shape[0]))
        mysrc_1= np.copy(self.src_pc)
        mysrc_2= np.copy(self.src_pc)
        myver= np.copy(self.ver_pc)
        mydst= np.copy(self.tar_pc)
        mylmsrc=np.copy(self.lm_src_pc)
        mylmtar=np.copy(self.lm_tar_pc)
        ###print("src &dst")
        ###print(mysrc)
        ###print(mydst)
        time_0 = time.time() 
        prev_error = 0
        iter_cnt=0
        ##print("mydst")
        ##print(mydst)
        '''
        for i in range(self.max_iter):
            indexes,error= self.findNearest_2(mydst, mysrc_2)
            ##print(distances)
            ##print(indices)
            R,T= self.getTransform(mydst[:, indexes],mysrc_2)
            mysrc_2 = (np.dot(R,mysrc_2)) + T[:, np.newaxis]
            self.H = self.update_homogeneous_matrix(self.H, R, T)
            #mean_error = np.mean(distances)
            dError = abs(prev_error - error)
            if dError < self.tolerance:
                break
            prev_error = error                
            iter_cnt += 1
            pass

        self.xdom[0] = self.H[0,2]
        self.xdom[1]=self.H[1,2]
        self.xdom[2]=math.atan2(self.H[1,0],self.H[0,0])
        '''
        '''
        time_1 = time.time()
        self.ekf1_time=self.ekf1_time+time_1-time_0
        prev_error = 0
        iter_cnt=0
        #print("before")
        #print(mylmtar)
        #print(mylmsrc)
        mylmtar,mylmsrc= self.findNearest(mylmtar,mylmsrc)
        #print("delta")
        lmnorm=np.linalg.norm(mylmtar-mylmsrc,ord=2,axis=0,keepdims=True)
        #print(lmnorm)
        totalrow=lmnorm.shape[1]
        i=0
        
        while True:
            if lmnorm[0,i]> 0.5:
                mylmtar = np.delete(mylmtar, i, axis=1)
                mylmsrc = np.delete(mylmsrc, i, axis=1)  
                lmnorm = np.delete(lmnorm, i, axis=1) 
                i=i-1
            i=i+1              
            if(i>=mylmsrc.shape[1]):
                break
        #print(mylmtar.shape[1])
        #print(np.linalg.norm(mylmtar-mylmsrc,ord=2,axis=0))
        #print("lmtar&src")
        #print(mylmtar)
        #print(mylmsrc)
        if(mylmtar.shape[1]!=0):
            for i in range(self.max_iter):
                indexes,error= self.findNearest_2(mylmtar, mylmsrc)
                R,T= self.getTransform(mylmtar[:, indexes],mylmsrc)
                mylmsrc = (np.dot(R,mylmsrc)) + T[:, np.newaxis]
                
                if(self.H3 is  None):
                    self.H3=self.H
                elif(i==0) and (self.H3 is not None):
                    self.H3 = self.H2
                else:
                    tmp = self.update_homogeneous_matrix(self.H3, R, T)
                    if (self.H3 is not None) and (math.hypot(tmp[0,2]-self.H3[0,2],tmp[1,2]-self.H3[1,2])<0.4):
                        self.H3=tmp
                    else:
                        self.H3=self.H2
                
                #self.H3 = self.update_homogeneous_matrix(self.H3, R, T)                
                #mean_error = np.mean(distances)
                dError = abs(prev_error - error)
                if dError < self.tolerance:
                    break
                prev_error = error                
                iter_cnt += 1
                pass
        

        time_2=time.time()
        self.ekf2_time=self.ekf2_time+time_2-time_1
        #print("itercnt")
        #print(iter_cnt)
        ##print("total_iter: ",iter_cnt)
        prev_error = 0
        iter_cnt=0
        '''


        oldH2=self.H2

        for i in range(self.max_iter):
            indexes,error= self.findNearest_2(myver, mysrc_1)
            ##print(distances)
            #print("indices")
            #print(indexes)
            #if(i==0):
             #   #print("ekfdelta")
              #  #print(np.linalg.no55rm(myver[:, indexes]-mysrc_1,ord=2,axis=0))
            R,T= self.getTransform(myver[:, indexes],mysrc_1)
            mysrc_1 = (np.dot(R,mysrc_1)) + T[:, np.newaxis]
            self.H2 = self.update_homogeneous_matrix(self.H2, R, T)
            #mean_error = np.mean(distances)
            dError = abs(prev_error - error)
            if dError < self.tolerance:
                break
            prev_error = error                
            iter_cnt += 1
            pass
        transform_acc=self.H
        ekf_acc=self.H2
        lm_acc=self.H2
        ##print(self.H3)
        ##print(self.H2)
        ##print("total_iter: ",iter_cnt)
        '''
        lmnorm=np.linalg.norm(myver[:, indexes]-mysrc_1,ord=2,axis=0,keepdims=True)
        #print(lmnorm)
        totalrow=lmnorm.shape[1]
        i=0
        
        while True:
            if lmnorm[0,i]> 0.6: 
                lmnorm = np.delete(lmnorm, i, axis=1) 
                i=i-1
            i=i+1              
            if(i>=lmnorm.shape[1]):
                break

        print(lmnorm.shape[1])
        time_3=time.time()
        self.ekf3_time=self.ekf3_time+time_3-time_2        
        #print("itercnt2")
        #print(iter_cnt)
        '''
        '''
        '''
        '''
        transform_acc=self.H
        ekf_acc=self.H2
        lm_acc=self.H3

        self.xdom[0] = self.H[0,2]
        self.xdom[1]=self.H[1,2]
        self.xdom[2]=math.atan2(self.H[1,0],self.H[0,0])
        ekf_yaw = math.atan2(transform_acc[1,0],transform_acc[0,0])
        self.H3[0,2]=self.H3[0,2]+random.uniform(0,0.1)
        self.H3[1,2]=self.H3[1,2]+random.uniform(-0.1,0)
        '''
        
        if (math.hypot(math.fabs(self.xEst[0]-self.H2[0,2]),math.fabs(self.xEst[1]-self.H2[1,2]))>0.5):
            self.xEst=xinput
            self.H2[0,2]=xinput[0]
            self.H2[1,2]=xinput[1]
            self.H2[0,0]=math.cos(xinput[2])
            self.H2[1,1]=math.cos(xinput[2])
            self.H2[1,0]=math.sin(xinput[2])
            self.H2[0,1]=-math.sin(xinput[2])
            print(msg)
        else:
            self.xEst[0]=self.H2[0,2]
            self.xEst[1]=self.H2[1,2]
            self.xEst[2]=math.atan2(self.H2[1,0],self.H2[0,0])
        
        #self.publishLandMark(self.landmarks_src,self.landmarks_tar)
        self.tar_pc = self.laserToNumpy(msg)
        self.target_laser=self.laserEstimation(msg,self.xEst)
        self.ver_pc=self.laserToNumpy(self.target_laser)
        #self.publishResult(transform_acc,lm_acc)
        #obs = self.u2T(self.xEst[0:3]).dot(self.src_pc)
        #pmap = self.mapping.update(obs[0], obs[1], self.xEst[0], self.xEst[1])
        #data = list(pmap.T.reshape(-1))
        #self.publishMap(pmap)        
        ##print("H2")

        ##print(self.H2)

        ##print(self.H)

        #self.calc_map_observation(msg,self.xEst)
        '''
        try:
            ##print("getmytf1")
            self.tf.waitForTransform("/map", "/robot_base", rospy.Time(), rospy.Duration(4.0))
            (self.trans,self.rot) = self.tf.lookupTransform('/map','/robot_base',rospy.Time(0))
            ##print("getmytf2")
        except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException):
            print("get tf error!")

        euler = tf.transformations.euler_from_quaternion(self.rot)
        roll,pitch,yaw = euler[0],euler[1],euler[2]
        print("start")
        print(self.trans[0])
        print(self.trans[1])
        self.txEst[0] = self.trans[0]#+np.random.uniform(-1,1,1)*0.03
        self.txEst[1] = self.trans[1]#+np.random.uniform(-1,1,1)*0.03
        self.txEst[2] = yaw#+np.random.uniform(-1,1,1)*0.02 
        '''


        #obs = self.u2T(self.txEst[0:3]).dot(self.src_pc)
        #pmap = self.mapping.update(obs[0], obs[1], self.txEst[0], self.txEst[1])
        #data = list(pmap.T.reshape(-1))
        #print(data)
        #self.publishMap(pmap)

        '''
        self.realpath.header.seq = 0
        self.realpath.header.stamp = rospy.Time(0)
        self.realpath.header.frame_id = 'map'
        pose = PoseStamped()
        pose.header.seq = self.indexi
        pose.header.stamp = rospy.Time(0)
        pose.header.frame_id = 'map'
        pose.pose.position.x = copy.deepcopy(self.txEst[0,0])
        pose.pose.position.y = copy.deepcopy(self.txEst[1,0])
        ###print(pose.pose.position.x)        
        ###print(pose.pose.position.y)
        pose.pose.position.z = 0.01
        pose.pose.orientation.x = 0
        pose.pose.orientation.y = 0
        pose.pose.orientation.z = 0
        pose.pose.orientation.w = 1
        self.tmpposes.append(copy.deepcopy(pose))
        self.realpath.poses=self.tmpposes
        self.realpath_pub.publish(self.realpath)
        #print(math.hypot(self.xEst[0]-self.txEst[0],self.xEst[1]-self.txEst[1]))
        
        # make points homogeneous, copy them to maintain the originals
       
        #self.publishLandMark(self.landmarks_src,self.landmarks_tar)
        self.tar_pc = self.laserToNumpy(msg)
        self.target_laser=self.laserEstimation(msg,self.xEst)
        self.ver_pc=self.laserToNumpy(self.target_laser)
        #self.publishResult(transform_acc,lm_acc)
        print("published")
        #self.landmarks_tar = self.extraction.process(self.laserEstimation(msg,self.txEst),True)
        #self.lm_tar_pc = self.lm2pc(self.landmarks_tar) 
        ##print("time_cost: ",time_1-time_0)        
        
        self.icpcloud.header.seq = 0
        self.icpcloud.header.stamp = rospy.Time(0)
        self.icpcloud.header.frame_id = 'map'
        points=Point32()
        points.x=copy.deepcopy(self.xEst[0,0])
        points.y=copy.deepcopy(self.xEst[1,0])
        points.z=0.01
        self.icppoints.append(copy.deepcopy(points))
        #self.icppoints[self.indexi].x=copy.deepcopy(self.xEst[0,0])
        #self.icppoints[self.indexi].y=copy.deepcopy(self.xEst[1,0])
        #self.icppoints[self.indexi].z=0.01
        ##print("icpp")
        ##print(self.icppoints)
        mchannels=ChannelFloat32()
        mchannels.name="rgb"
        for i in range(0,len(self.icppoints)):
            mchannels.values.append(110)
        self.icpcloud.points=self.icppoints
        self.icpcloud.channels.append(mchannels)
        self.icpp_pub.publish(self.icpcloud)
        self.icpcloud2.header.seq = 0
        self.icpcloud2.header.stamp = rospy.Time(0)
        self.icpcloud2.header.frame_id = 'map'


        points2=Point32()
        points2.x=copy.deepcopy(transform_acc[0,2])
        points2.y=copy.deepcopy(transform_acc[1,2])
        points2.z=0.01
        self.icppoints2.append(copy.deepcopy(points2))

        #self.icppoints[self.indexi].x=copy.deepcopy(self.xEst[0,0])

        #self.icppoints[self.indexi].y=copy.deepcopy(self.xEst[1,0])

        #self.icppoints[self.indexi].z=0.01

        ##print("icpp2")

        ##print(self.icppoints2)
        mchannels=ChannelFloat32()
        mchannels.name="rgb"
        for i in range(0,len(self.icppoints)):
            mchannels.values.append(250)
        self.icpcloud2.points=self.icppoints2
        self.icpcloud2.channels.append(mchannels)
        self.icpp_pub2.publish(self.icpcloud2)

        self.icpcloud3.header.seq = 0
        self.icpcloud3.header.stamp = rospy.Time(0)
        self.icpcloud3.header.frame_id = 'map'


        points3=Point32()
        points3.x=copy.deepcopy(self.H2[0,2]+random.uniform(0,0.08))
        points3.y=copy.deepcopy(self.H2[1,2]+random.uniform(-0.08,0))
        points3.z=0.01
        self.icppoints3.append(copy.deepcopy(points3))

        #self.icppoints[self.indexi].x=copy.deepcopy(self.xEst[0,0])

        #self.icppoints[self.indexi].y=copy.deepcopy(self.xEst[1,0])

        #self.icppoints[self.indexi].z=0.01

        ##print("icpp2")

        ##print(self.icppoints2)
        mchanne3s=ChannelFloat32()
        mchanne3s.name="rgb"
        for i in range(0,len(self.icppoints)):
            mchanne3s.values.append(10)
        self.icpcloud3.points=self.icppoints3
        self.icpcloud3.channels.append(mchanne3s)
        self.icpp_pub3.publish(self.icpcloud3)




        
        self.indexi=self.indexi+1
        #print(round(1000*self.ekf1_time))
        #print(round(1000*self.ekf2_time))
        #print(round(1000*self.ekf3_time))
        #print(self.jishuqi)
        ##print(self.calcDist(self.xEst,self.txEst)/self.calcDist(self.xdom,self.txEst))
        '''
        xinput=self.xEst
        return self.xEst



    def publishMap(self,pmap):
        map_msg = OccupancyGrid()
        map_msg.header.seq = 1
        map_msg.header.stamp = rospy.Time().now()
        map_msg.header.frame_id = "map"

        map_msg.info.map_load_time = rospy.Time().now()
        map_msg.info.resolution = self.map_reso
        map_msg.info.width = self.map_cellx_width
        map_msg.info.height = self.map_celly_width
        map_msg.info.origin.position.x = -self.map_cellx_width*self.map_reso/2.0
        map_msg.info.origin.position.y = -self.map_celly_width*self.map_reso/2.0
        map_msg.info.origin.position.z = 0
        map_msg.info.origin.orientation.x = 0
        map_msg.info.origin.orientation.y = 0
        map_msg.info.origin.orientation.z = 0
        map_msg.info.origin.orientation.w = 1.0

        map_msg.data = list(pmap.T.reshape(-1))
        
        self.map_pub.publish(map_msg)





    def updateMap(self,msg):

        ##print("debug: try update map obstacle")

        
        '''
        rospy.wait_for_service('/static_map')

        try:

            getMap = rospy.ServiceProxy('/static_map',GetMap)

            self.map = getMap().map

            # ##print(self.map)

        except:

            e = sys.exc_info()[0]

            ##print('Service call failed: %s'%e)
        '''
        
        self.map=msg
        self.mapdata=msg.data

        # Update for planning algorithm
        
        self.map_data = np.array(self.mapdata).reshape((-1,msg.info.height)).transpose()#heigh=129
       

        tx,ty = np.nonzero((self.map_data > 20)|(self.map_data < -0.5))

        ox = (tx*msg.info.resolution+msg.info.origin.position.x)*1.0

        oy = (ty*msg.info.resolution+msg.info.origin.position.y)*1.0

        self.obstacle = np.vstack((ox,oy)).transpose()
        ##print("debug: update map obstacle success! ")

    '''
    
    def laserEstimation(self,msg,x):

        data=LaserScan()
        data=msg
        data.ranges=list(msg.ranges)
        data.intensities=list(msg.intensities)



        #data.angle_min= -3.14159011841

        #data.angle_max= 3.14159011841

        #data.angle_increment= 0.0527998320758

        for i in range(0,len(data.ranges)):
            data.ranges[i]=30
            data.intensities[i]=0.5
        #tx,ty = np.nonzero((self.map_data > 20)|(self.map_data < -0.5))
        #ox = (tx*self.map.info.resolution+self.map.info.origin.position.x-x[0,1])*1.0
        #oy = (ty*self.map.info.resolution+self.map.info.origin.position.y-x[1,2])*1.0
        ###print("shape")
        ###print(self.obstacle.shape[0])
        for i in range(0,len(self.obstacle)):
            ox=self.obstacle[i,0]-x[0,0]
            oy=self.obstacle[i,1]-x[1,0]
            #ox=self.obstacle[i,0]-0
            #oy=self.obstacle[i,1]-0
            alpha=math.atan2(oy,ox)-x[2,0]
            rou=math.hypot(ox,oy)
            ###print("rou"+str(rou)+"alpha"+str(alpha))
            delta_alpha=math.atan2(self.obstacle_r/2,rou)
            alpha_min=math.atan2(math.sin(alpha-delta_alpha),math.cos(alpha-delta_alpha))
            alpha_max=math.atan2(math.sin(alpha+delta_alpha),math.cos(alpha+delta_alpha))
            index_min=int(np.floor(abs((alpha_min+math.pi)/msg.angle_increment)))
            index_max=int(np.floor(abs((alpha_max+math.pi)/msg.angle_increment)))
            ###print("min"+str(index_min)+"max"+str(index_max))

            if index_min<=index_max:

                for index in range(index_min,index_max+1):

                    if data.ranges[index]>rou:

                        data.ranges[index]=rou



            else:

                ##print(">>>>>>>>>>>>>>>>>>>")

                for index in range(0,index_max+1):

                    if data.ranges[index]>rou:

                        data.ranges[index]=rou               

                for index in range(index_min,len(msg.ranges)):

                    if data.ranges[index]>rou:

                        data.ranges[index]=rou 

        

        ###print(data)

        self.target_laser=data;

        return data;
    
    '''
    def laserEstimation(self,msg,x):
        data=LaserScan()
        data=msg
        data.ranges=list(msg.ranges)
        data.intensities=list(msg.intensities)
        step=self.map.info.resolution
        for i in range(0,len(data.ranges)):
            data.ranges[i]=30
            data.intensities[i]=0.5
        for i in range(len(msg.ranges)):
            angle=i*msg.angle_increment+msg.angle_min+x[2,0]
            step_x=step*math.cos(angle)
            step_y=step*math.sin(angle)
            for j in range(int(np.floor(data.range_max/step))):
                index_y=int(np.floor((j*step_x+x[0,0]-self.map.info.origin.position.x)/self.map.info.resolution)) 
                index_x=int(np.floor((j*step_y+x[1,0]-self.map.info.origin.position.y)/self.map.info.resolution)) 
                map_data=self.map.data[index_x*self.map.info.width+index_y]
                if(map_data>20 or map_data<-0.5):
                    data.ranges[i]=j*step
                    break
        return data;
    

    def lm2pc(self,lm):
        total_num = len(lm.id)
        dy = lm.position_y
        dx = lm.position_x
        range_l = np.hypot(dy,dx)
        angle_l = np.arctan2(dy,dx)
        pc = np.ones((3,total_num))
        pc[0:2,:] = np.vstack((np.multiply(np.cos(angle_l),range_l),np.multiply(np.sin(angle_l),range_l)))
        ##print("mdbg ",total_num)
        return pc

    def T2u(self,t):
        dw = math.atan2(t[1,0],t[0,0])
        u = np.array([[t[0,2],t[1,2],dw]])
        return u.T

    def u2T(self,u):
        w = u[2]
        dx = u[0]
        dy = u[1]

        return np.array([
            [ math.cos(w),-math.sin(w), dx],
            [ math.sin(w), math.cos(w), dy],
            [0,0,1]
        ])


    def publishLandMark(self,msg,msg2):
        # msg = LandMarkSet()
        if len(msg.id) <= 0:
            return
        #print("size")
        #print(len(msg.id))
        #print(len(msg2.id))

        landMark_array_msg = MarkerArray()
        
        
        for i in range(len(msg.id)):
            marker = Marker()
            marker.header.frame_id = "course_agv__hokuyo__link"
            marker.header.stamp = rospy.Time(0)
            marker.ns = "lm"
            marker.id = i
            marker.type = Marker.SPHERE
            marker.action = Marker.ADD
            marker.pose.position.x = msg.position_x[i]
            marker.pose.position.y = msg.position_y[i]
            marker.pose.position.z = 0 # 2D
            marker.pose.orientation.x = 0.0
            marker.pose.orientation.y = 0.0
            marker.pose.orientation.z = 0.0
            marker.pose.orientation.w = 1.0
            marker.scale.x = 0.2
            marker.scale.y = 0.2
            marker.scale.z = 0.2
            marker.color.a = 0.5 # Don't forget to set the alpha
            marker.color.r = 0.0
            marker.color.g = 0.0
            marker.color.b = 1.0
            landMark_array_msg.markers.append(marker)
        '''  
        for i in range(len(msg2.id)):
            marker = Marker()
            marker.header.frame_id = "course_agv__hokuyo__link"
            marker.header.stamp = rospy.Time(0)
            marker.ns = "lm"
            marker.id = i+len(msg.id)
            marker.type = Marker.SPHERE
            marker.action = Marker.ADD
            marker.pose.position.x = msg2.position_x[i]
            marker.pose.position.y = msg2.position_y[i]
            marker.pose.position.z = 0 # 2D
            marker.pose.orientation.x = 0.0
            marker.pose.orientation.y = 0.0
            marker.pose.orientation.z = 0.0
            marker.pose.orientation.w = 1.0
            marker.scale.x = 0.2
            marker.scale.y = 0.2
            marker.scale.z = 0.2
            marker.color.a = 0.5 # Don't forget to set the alpha
            marker.color.r = 0.0
            marker.color.g = 1.0
            marker.color.b = 0.0
            landMark_array_msg.markers.append(marker)    
        '''
        self.landMark_pub.publish(landMark_array_msg)


    def calc_map_observation(self,msg,x):
        landmarks_src = self.extraction.process2(msg,True)
        landmarks_tar = self.extraction.process2(self.laserEstimation(msg,x),True)
        #print("lm : ",len(self.landmarks_src.id),len(landmarks_tar.id))
        self.publishLandMark(self.landmarks_src,self.landmarks_tar)
        #src_pc = self.lm2pc(landmarks_src)
        #tar_pc = self.lm2pc(landmarks_tar)
        #transform_acc = self.icp.process(tar_pc,src_pc)
        #return self.T2u(transform_acc)

    '''

    def findNearest(self,previous_points, current_points):

        

        # calc the sum of residual errors

        delta_points = previous_points - current_points

        d = np.linalg.norm(delta_points, axis=0)

        error = sum(d)



        # calc index with nearest neighbor assosiation

        d = np.linalg.norm(np.repeat(current_points, previous_points.shape[1], axis=1)

                        - np.tile(previous_points, (1, current_points.shape[1])), axis=0)

        indexes = np.argmin(d.reshape(current_points.shape[1], previous_points.shape[1]), axis=1)



        return indexes, error
    '''


    def findNearest_2(self,previous_points, current_points):
        
        # calc the sum of residual errors
        delta_points = previous_points - current_points
        d = np.linalg.norm(delta_points, axis=0)
        error = sum(d)

        # calc index with nearest neighbor assosiation
        d = np.linalg.norm(np.repeat(current_points, previous_points.shape[1], axis=1)
                        - np.tile(previous_points, (1, current_points.shape[1])), axis=0)
        indexes = np.argmin(d.reshape(current_points.shape[1], previous_points.shape[1]), axis=1)

        return indexes, error


    '''
    def findNearest(self,previous_points, current_points):
        if (previous_points.shape[1]==current_points.shape[1]):
            pre_group=previous_points
            cur_group=current_points
        else:
            if (current_points.shape[1]<previous_points.shape[1]):
                newline=np.ones([3,1])
                newline[0,0]=99
                newline[1,0]=99
                for i in range(0,previous_points.shape[1]-current_points.shape[1]):
                    current_points=np.hstack((current_points,newline))
                pre_group=previous_points
                cur_group=current_points
            else:
                tmp_points=current_points
                current_points=previous_points
                previous_points=tmp_points
                newline=np.ones([3,1])
                newline[0,0]=99
                newline[1,0]=99
                for i in range(0,previous_points.shape[1]-current_points.shape[1]):
                    current_points=np.hstack((current_points,newline))
                pre_group=current_points 
                cur_group=previous_points  
        #print("pre")
        #print(pre_group)
        #print("cur") 
        #print(cur_group)    
        return pre_group,cur_group

    '''    
    def findNearest(self,previous_points, current_points):
        if (previous_points.shape[1]==current_points.shape[1]):
            pre_group=previous_points
            cur_group=current_points
        else:
            if (current_points.shape[1]<previous_points.shape[1]):
                d = np.linalg.norm(np.repeat(current_points, previous_points.shape[1], axis=1)
                                - np.tile(previous_points, (1, current_points.shape[1])), axis=0)
                indexes = np.argmin(d.reshape(current_points.shape[1], previous_points.shape[1]), axis=1)
                pre_group=previous_points[:, indexes]
                cur_group=current_points
            else:
                tmp_points=current_points
                current_points=previous_points
                previous_points=tmp_points
                d = np.linalg.norm(np.repeat(current_points, previous_points.shape[1], axis=1)
                                - np.tile(previous_points, (1, current_points.shape[1])), axis=0)
                indexes = np.argmin(d.reshape(current_points.shape[1], previous_points.shape[1]), axis=1)
                pre_group=current_points 
                cur_group=previous_points[:, indexes]   
        #print("pre")
        #print(pre_group)
        #print("cur") 
        #print(cur_group)    
        return pre_group,cur_group
  


    '''
    def findNearest(self,previous_points, current_points):
        if (previous_points.shape[1]==current_points.shape[1]):
            # calc the sum of residual errors
            delta_points = previous_points - current_points
            d = np.linalg.norm(delta_points, axis=0)
            error = sum(d)

            # calc index with nearest neighbor assosiation

            d = np.linalg.norm(np.repeat(current_points, previous_points.shape[1], axis=1)

                            - np.tile(previous_points, (1, current_points.shape[1])), axis=0)

            indexes = np.argmin(d.reshape(current_points.shape[1], previous_points.shape[1]), axis=1)
            pre_group=previous_points[:, indexes]
            cur_group=current_points
        
        else:
            if (current_points.shape[1]<previous_points.shape[1]):
                error=0
                for i in range(0,3):
                    for j in range(0,min(previous_points.shape[1],current_points.shape[1])):
                        error=error+abs(previous_points[i,j]-current_points[i,j])

                d = np.linalg.norm(np.repeat(current_points, previous_points.shape[1], axis=1)

                                - np.tile(previous_points, (1, current_points.shape[1])), axis=0)

                indexes = np.argmin(d.reshape(current_points.shape[1], previous_points.shape[1]), axis=1)
                pre_group=previous_points[:, indexes]
                cur_group=current_points
            
            else:
                tmp_points=current_points
                current_points=previous_points
                previous_points=tmp_points
                error=0
                for i in range(0,3):
                    for j in range(0,min(previous_points.shape[1],current_points.shape[1])):
                        error=error+abs(previous_points[i,j]-current_points[i,j])
                d = np.linalg.norm(np.repeat(current_points, previous_points.shape[1], axis=1)

                                - np.tile(previous_points, (1, current_points.shape[1])), axis=0)
                indexes = np.argmin(d.reshape(current_points.shape[1], previous_points.shape[1]), axis=1)
                pre_group=current_points 
                cur_group=previous_points[:, indexes]   


        #print(pre_group) 
        #print(cur_group)    
        return pre_group,cur_group,error
  



        for _ in range(self.max_iter):
    
            indexes,error= self.findNearest(myver, mysrc_1)

            ###print(distances)

            ###print(indices)

            R,T= self.getTransform(myver[:, indexes],mysrc_1)

            mysrc_1 = (np.dot(R,mysrc_1)) + T[:, np.newaxis]

            self.H2 = self.update_homogeneous_matrix(self.H2, R, T)

            #mean_error = np.mean(distances)

            dError = abs(prev_error - error)

            if dError < self.tolerance:

                break

            prev_error = error                

            iter_cnt += 1

            pass



        '''


    def update_homogeneous_matrix(self,Hin, R, T):

    

        H = np.zeros((3, 3))



        H[0, 0] = R[0, 0]

        H[1, 0] = R[1, 0]

        H[0, 1] = R[0, 1]

        H[1, 1] = R[1, 1]

        H[2, 2] = 1.0

        H[2, 0] = 0

        H[2, 1] = 0

        H[0, 2] = T[0]

        H[1, 2] = T[1]

        if Hin is None:

            return H

        else:

            return np.dot(Hin,H)




    def update_homogeneous_matrix_2(self,Hin, R, T):
    
    

        H = np.zeros((3, 3))



        H[0, 0] = R[0, 0]

        H[1, 0] = R[1, 0]

        H[0, 1] = R[0, 1]

        H[1, 1] = R[1, 1]

        H[2, 2] = 1.0

        H[2, 0] = 0

        H[2, 1] = 0

        H[0, 2] = T[0]

        H[1, 2] = T[1]


        return H





    

    def getTransform(self,src,tar):

        T = np.identity(3)

        pm = np.mean(src, axis=1)

        cm = np.mean(tar, axis=1)

        p_shift = src- pm[:, np.newaxis]

        c_shift = tar - cm[:, np.newaxis]        

        W = np.dot(c_shift,p_shift.T)



        ###print(c_shift)

        ###print(p_shift)

        ###print("w is")

        ###print(W)

        try:

            u, s, vh = np.linalg.svd(W)

        except Exception as e:

            print(e)

            print(src)

            print(tar)



        R = (np.dot(u,vh)).T

        T = pm - (np.dot(R,cm))

        ###print("this is T2")

        ###print(T)

        return R, T





    def publishResult(self,T,TLM):


        s = self.xEst
        q = tf.transformations.quaternion_from_euler(0,0,s[2])
        self.odom_broadcaster_2.sendTransform((s[0],s[1],0.001),(q[0],q[1],q[2],q[3]),
                           rospy.Time.now(),"ekf_location","world_base")
        # odom
        aodom = Odometry()
        aodom.header.stamp = rospy.Time.now()
        aodom.header.frame_id = "world_base"
        aodom.pose.pose.position.x = s[0]+0.2
        aodom.pose.pose.position.y = s[1]+0.2
        aodom.pose.pose.position.z = 0.001
        aodom.pose.pose.orientation.x = q[0]
        aodom.pose.pose.orientation.y = q[1]
        aodom.pose.pose.orientation.z = q[2]
        aodom.pose.pose.orientation.w = q[3]
        ###print(aodom)
        self.location_pub.publish(aodom)

        s = self.txEst
        q = tf.transformations.quaternion_from_euler(0,0,s[2])
        self.odom_broadcaster_2.sendTransform((s[0],s[1],0.001),(q[0],q[1],q[2],q[3]),
                           rospy.Time.now(),"lm_location","world_base")
        # odom
        codom = Odometry()
        codom.header.stamp = rospy.Time.now()
        codom.header.frame_id = "world_base"
        codom.pose.pose.position.x = s[0]
        codom.pose.pose.position.y = s[1]
        codom.pose.pose.position.z = 0.001
        codom.pose.pose.orientation.x = q[0]
        codom.pose.pose.orientation.y = q[1]
        codom.pose.pose.orientation.z = q[2]
        codom.pose.pose.orientation.w = q[3]
        ###print(aodom)
        self.location_lm_pub.publish(codom)

        
        
  #sdsjadhsajkdjhaskdhahdkasjdhjkahdksadhjshdkadhsjdhajkdhsjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj
        delta_yaw = math.atan2(T[1,0],T[0,0])
        ##print("sensor-delta-xyt: ",T[0,2],T[1,2],delta_yaw)
        #self.sensor_sta[0] = s[0] + math.cos(s[2])*T[0,2] - math.sin(s[2])*T[1,2]
        #self.sensor_sta[1] = s[1] + math.sin(s[2])*T[0,2] + math.cos(s[2])*T[1,2]
        #self.sensor_sta[2] = s[2] + delta_yaw
        self.sensor_sta[0] = T[0,2]
        self.sensor_sta[1] = T[1,2]
        self.sensor_sta[2] = delta_yaw
        ##print("sensor-global: ",self.sensor_sta)
        # tf
        s = self.sensor_sta
        q = tf.transformations.quaternion_from_euler(0,0,self.sensor_sta[2])
        self.odom_broadcaster.sendTransform((s[0],s[1],0.001),(q[0],q[1],q[2],q[3]), rospy.Time.now(),"icp_odom_2","world_base")
        self.map_broadcaster.sendTransform((0,0,0),tf.transformations.quaternion_from_euler(0, 0,0), rospy.Time.now(),"world_base","map")
        ##print("tfsend")
        # odom
        odom = Odometry()
        odom.header.stamp = rospy.Time.now()
        odom.header.frame_id = "world_base"
        odom.pose.pose.position.x = s[0]
        odom.pose.pose.position.y = s[1]
        odom.pose.pose.position.z = 0.001
        odom.pose.pose.orientation.x = q[0]
        odom.pose.pose.orientation.y = q[1]
        odom.pose.pose.orientation.z = q[2]
        odom.pose.pose.orientation.w = q[3]
        self.odom_pub.publish(odom)
        self.laser_pub.publish(self.target_laser)
        
        '''
        delta_yaw = math.atan2(TLM[1,0],TLM[0,0])
        ##print("sensor-delta-xyt: ",T[0,2],T[1,2],delta_yaw)
        s = self.sensor_sta
        #self.sensor_sta[0] = s[0] + math.cos(s[2])*T[0,2] - math.sin(s[2])*T[1,2]
        #self.sensor_sta[1] = s[1] + math.sin(s[2])*T[0,2] + math.cos(s[2])*T[1,2]
        #self.sensor_sta[2] = s[2] + delta_yaw
        self.sensor_sta[0] = TLM[0,2]
        self.sensor_sta[1] = TLM[1,2]
        self.sensor_sta[2] = delta_yaw+random.uniform(-0.05,0.05)
        ##print("sensor-global: ",self.sensor_sta)
        # tf
        s = self.sensor_sta
        q = tf.transformations.quaternion_from_euler(0,0,self.sensor_sta[2])
        self.odom_broadcaster_3.sendTransform((s[0],s[1],0.001),(q[0],q[1],q[2],q[3]),
                             rospy.Time.now(),"lm_location","world_base")
        ##print("tfsend")
        # odom
        bodom = Odometry()
        bodom.header.stamp =rospy.Time.now()
        bodom.header.frame_id = "world_base"
        bodom.pose.pose.position.x = s[0]
        bodom.pose.pose.position.y = s[1]
        bodom.pose.pose.position.z = 0.001
        bodom.pose.pose.orientation.x = q[0]
        bodom.pose.pose.orientation.y = q[1]
        bodom.pose.pose.orientation.z = q[2]
        bodom.pose.pose.orientation.w = q[3]
        self.location_lm_pub.publish(bodom)
        '''
        pass
        

    def laserToNumpy(self,msg):
        total_num = len(msg.ranges)
        pc = np.ones([3,total_num])
        range_l = np.array(msg.ranges)
        range_l[range_l==np.inf]=20
        range_l[range_l==np.nan]=20
        angle_l = np.linspace(msg.angle_min,msg.angle_max,total_num)
        pc[0:2,:] = np.vstack((np.multiply(np.cos(angle_l),range_l),np.multiply(np.sin(angle_l),range_l)))
        return pc



    def calcDist(self,a,b):

        dx = a[0] - b[0]

        dy = a[1] - b[1]

        return math.hypot(dx,dy)


class NeighBor:
    def __init__(self):
        self.distances = []
        self.src_indices = []
        self.tar_indices = []

class Localization(object):
    def __init__(self,nodeName):
        self.nodeName=nodeName
        # State Vector [x y yaw].T, column vector.
        self.xEst=np.zeros((3,1))
        self.odom_pub = rospy.Publisher(nodeName,Odometry,queue_size=1)
        self.odom_broadcaster=tf.TransformBroadcaster()

    def publishResult(self):
        self.odom_pub.publish(self.statusToOdometry(self.xEst))

        # flatten out
        s=np.array(self.xEst).reshape(-1)
        #print("sensor-global  : {}".format(s))

        # tf broadcast
        q = tf.transformations.quaternion_from_euler(0,0,s[2])
        self.odom_broadcaster.sendTransform((s[0],s[1],0.001),(q[0],q[1],q[2],q[3]),
                            rospy.Time.now(),self.nodeName,"world_base")

    def translateResult(self,T):
        # what exactly is this T? T is a affine transformation matrix of 1 higher order.
        # print("T: {}".format(T))
        delta_yaw = math.atan2(T[1,0],T[0,0])
        # [[cos(theta),-sin(theta)],[sin(theta),cos(theta)]]
        # print("sensor-delta-xyt:[{},{},{}]".format(T[0,2],T[1,2],delta_yaw))
        # improved readability
        # rotation=T[0:2,0:2]
        translation=T[0:2,2].reshape(2,1)
        x,y,theta=self.xEst
        theta+=delta_yaw
        # the position of theta+=delta_yaw needs consideration.
        eulerMatrix=tf.transformations.euler_matrix(0,0,theta)[0:2,0:2]
        x,y=np.array([x,y])+np.dot(eulerMatrix,translation)
        self.xEst=np.array([x,y,theta])
        
        # s = self.sensor_sta
        # self.sensor_sta[0] = s[0] + math.cos(s[2])*T[0,2] - math.sin(s[2])*T[1,2]
        # self.sensor_sta[1] = s[1] + math.sin(s[2])*T[0,2] + math.cos(s[2])*T[1,2]
        # self.sensor_sta[2] = s[2] + delta_yaw
    
    def statusToOdometry(self,sensorStatus):
        # flatten out
        s=np.array(sensorStatus).reshape(-1)
        q = tf.transformations.quaternion_from_euler(0,0,s[2])
        # odom topic publish
        odom = Odometry(header=Header(0,rospy.Time.now(),"world_base"))
        # odom.header.stamp = rospy.Time.now()
        # odom.header.frame_id = "world_base"

        # odom.pose.pose.position.x = s[0]
        # odom.pose.pose.position.y = s[1]
        # odom.pose.pose.position.z = 0
        odom.pose.pose.position=Point(s[0],s[1],0)
        # odom.pose.pose.orientation.x = q[0]
        # odom.pose.pose.orientation.y = q[1]
        # odom.pose.pose.orientation.z = q[2]
        # odom.pose.pose.orientation.w = q[3]
        odom.pose.pose.orientation=Quaternion(q[0],q[1],q[2],q[3])

        return odom

    def calcDist(self,a,b):
        dx = a[0] - b[0]
        dy = a[1] - b[1]
        return math.hypot(dx,dy)

    def T2u(self,t):
        '''
        translate relative transform matrix T to relative u.
        Note that relative u is according to self frame.
        x=x+[[R,0],[0,1]] u
        '''
        dw = math.atan2(t[1,0],t[0,0])
        u = np.array([[t[0,2],t[1,2],dw]])
        # .T can be viewed as transpose in 2 dimentional matrix.
        return u.T

    def x2T(self,x):
        T=tf.transformations.euler_matrix(0,0,x[2,0])[0:3,0:3]
        T[0:2,2]=x[0:2,0]

class ICPBase(Localization):
    def __init__(self,nodeName="icp_odom"):

        self.inf=1e6
        
        super(ICPBase,self).__init__(nodeName)

        # robot init states
        self.robot_x = float(rospy.get_param('/icp/robot_x',0))
        self.robot_y = float(rospy.get_param('/icp/robot_y',0))
        self.robot_theta = float(rospy.get_param('/icp/robot_theta',0))     
        
        # sensor's estimation for current state = robot_x_y_theta, overrides Localization.
        self.xEst = np.array([[self.robot_x,self.robot_y,self.robot_theta]]).T
        # if is the first scan, set as the map/target
        self.isFirstScan = True
        # src point cloud matrix
        self.src_pc=None
        # target point cloud matrix
        self.tar_pc=None

        

        self.laser_count  = 0
        # interval should not be set too small(like 1). Recommend that process once every 5 laser frames
        self.laser_interval= 5
        
        # max iterations
        self.max_iter = int(rospy.get_param('/icp/max_iter',10))
        # distance threshold for matching points
        self.dis_th = float(rospy.get_param('/icp/dis_th',0.5))
        # tolerance to stop icp
        self.tolerance = float(rospy.get_param('/icp/tolerance',0))

        # for wheel odometry.
        self.estimatedPose=Pose(position=Point(0,0,0),orientation=Quaternion(0,0,0,1))

    def processICP(self,source,target,initialT=None):
        '''
        Process the fitting between source and target.
        Returns T the transformation matrix.
        source and target is guarenteed not to be accidentally changed.
        initial argument pass in the initial value of T.
        If set to None, use Wheel odometry reference
        '''
        # init some variables
        src=np.copy(source)
        tar=np.copy(target)
        if initialT is None:
            try:
                # wheel auxilary. If you wnat to avoid it, pass in an identity(3) as initial.
                rospy.wait_for_service("/course_agv/odometry",timeout=0.1)
                newPose=rospy.ServiceProxy("/course_agv/odometry",Odometry_srv)()
                newPose=newPose.pose
                # print("New Pose(Wheel):{}".format(newPose))
                # print("type: {}".format(type(newPose)))
                # print("Original Pose(Wheel):{}".format(self.estimatedPose))
                # print("type: {}".format(type(self.estimatedPose)))
                translation=toArray(newPose.position)-toArray(self.estimatedPose.position)
                translation=translation[0:2]
                newEuler=tf.transformations.euler_from_quaternion(toList(newPose.orientation))
                oldEuler=tf.transformations.euler_from_quaternion(toList(self.estimatedPose.orientation))
                rotation=tf.transformations.euler_matrix(0,0,newEuler[2]-oldEuler[2])[0:2,0:2]
                # change to self frame
                
                translation=np.dot(tf.transformations.euler_matrix
                        (oldEuler[0],oldEuler[1],-oldEuler[2])[0:2,0:2],translation)
                self.estimatedPose=newPose
            except rospy.ROSException, e:
                print("wheel odometry failed: {}".format(e))
                # fallback to no reference.
                rotation = np.identity(2)
                translation=np.zeros(2)
        else:
            rotation = initialT[0:2,0:2]
            translation=initialT[0:2,2]

        # print("initial rotation:\n{} \ntranslation:{}".format(rotation,translation))
        # FIXME: learn about relativity! the laser in the frame moves opposite
        translation=-translation
        rotation=np.transpose(rotation)
        iterations=0
        # temp=np.copy(tar)
        lastDeviation=self.inf
        
        # don't move src_pc, adjust tar_pc to fit src.
        for _ in range(self.max_iter): # I haven't seen this grammar before...
            # transform tar_pc:
            iterations += 1
            # elegant matrix multiplying
            temp=np.dot(rotation,tar)+translation.reshape((2,1))
            neighbour=self.findNearest(src,temp)
            deviation=np.sum(neighbour.distances)
            # print("d= {} (iterations{})".format(deviation,iterations))
            if lastDeviation==deviation or deviation<self.tolerance*len(neighbour.src_indices):
                break
            lastDeviation=deviation
            # change the pairing rule
            tempTar=tar[:,neighbour.tar_indices] # elegant and pythonic!
            tempSrc=src[:,neighbour.src_indices]
            rotation,translation=self.getTransform(tempSrc,tempTar)
                  
        # print("--------------------------------------")
        # print("total iterations: {}".format(iterations))
        # print("total deviation: {}".format(np.sum(neighbour.distances)))
        T=np.identity(3)
        # because of the relative relation between frames, R and T should reverse
        T[0:2,0:2]=np.transpose(rotation)
        T[0:2,2]=-translation
        # error dealing.
        if np.any(np.isnan(T)):
            return np.identity(3)
        return T

    def findNearest(self,src,tar):
        '''
        guarantees that src and tar won't change.
        '''
        # find the pairing strategy between src and tar.
        neighbour = NeighBor()
        length=np.size(src,1)
        # allows one-to-multiple pair
        for i in range(length):
            # np parallel computing is much faster than looping. Compare the code commented out and this!
            temp=np.linalg.norm(tar-src[:,i].reshape(2,1),axis=0) # distance
            # temp=[np.linalg.norm(tar[:,j]-src[:,i]) for j in range(length)]
            index=np.argmin(temp)
            # filter out the non-matching point pairs
            if temp[index]<self.dis_th:
                neighbour.src_indices.append(i)
                neighbour.tar_indices.append(index)
                neighbour.distances.append(temp[index])
        
        # print("neighbour:\n\ttar_indices:{}".format(neighbour.tar_indices))
        # print("\tdistances:{}".format(neighbour.distances))
        return neighbour

    def getTransform(self,src,tar):
        '''
        guarantees that src and tar won't change.
        '''
        # be very careful that the arguments are passed in as references.
        if np.size(src,1)!= np.size(tar,1):
            print("error in length!")
            # skipping
            return(np.identity(2),np.array([0,0]))
        length=np.size(src,1)
        srcCenter=np.mean(src,axis=1)
        tarCenter=np.mean(tar,axis=1)
        
        # print("srcCenter:{}".format(srcCenter))
        # print("tarCenter:{}".format(tarCenter))
        
        # ELEGANT!
        srcPrime=src-srcCenter.reshape((2,1))
        tarPrime=tar-tarCenter.reshape((2,1))
        W=np.dot(tarPrime,srcPrime.T)
        # print("W={}".format(W))
        U,S,V=np.linalg.svd(W)
        # FIXME: notice the difference of svd decomposing declaration! W=U*diag(S)*V
        rotation=np.transpose(np.dot(U,V))
        translation=srcCenter-np.dot(rotation,tarCenter)
        # print("rotation:{}".format(rotation))
        # print("translation:{}".format(translation))
        return (rotation,translation)
       
    def laserToNumpy(self,msg):
        # the x,y coordinates are in robot's frame?
        total_num = len(msg.ranges)
        # pc = np.ones([3,total_num])
        range_l = np.array(msg.ranges)
        angle_l = np.linspace(msg.angle_min,msg.angle_max,total_num)
        # ufunc, high performance
        pc = np.vstack((np.multiply(np.cos(angle_l),range_l),np.multiply(np.sin(angle_l),range_l)))
        # print("Numpy pc:{}".format(pc))
        return pc

class ICP(ICPBase):
    def __init__(self,nodeName="icp_odom"):
        super(ICP,self).__init__(nodeName)

        self.laser_sub = rospy.Subscriber('/course_agv/laser/scan',LaserScan,self.laserCallback,queue_size=self.laser_interval)
    
    def laserCallback(self,msg):
        # process and fit laser pointcloud data. 
        # callback is a little messy.
        print('------seq:  ',msg.header.seq)
        if not np.any(self.tar_pc):
            self.tar_pc = self.laserToNumpy(msg)
            # self.isFirstScan = False
            self.laser_count = 0
            return
        
        # process once every 5 laser scan because laser fps is too high
        self.laser_count += 1
        if self.laser_count < self.laser_interval:
            return
        self.laser_count = 0
        time_0 = rospy.Time.now()
        self.src_pc = self.laserToNumpy(msg)
        # print('input cnt: ',self.src_pc.shape[1])

        T=self.processICP(self.src_pc,self.tar_pc,initialT=np.identity(3))
        self.tar_pc = np.copy(self.src_pc) # moving the target to src
        self.translateResult(T)
        self.publishResult()
        duration=rospy.Time.now()-time_0
        #print("time_cost: {} s".format(duration.to_sec()))
        pass

# used in localization.py
class SubICP(ICPBase):
    '''
    The management of firstScan etc. are moved to the Localization 
    object to handle.
    '''
    def __init__(self):
        super(SubICP,self).__init__()
    
    def laserCallback(self,msg):
        '''
        laser ICP odometry.
        '''
        time_0 = rospy.Time.now()
        self.src_pc = self.laserToNumpy(msg)
        # print('input cnt: ',self.src_pc.shape[1])

        T=self.processICP(self.src_pc,self.tar_pc,initialT=np.identity(3))
        self.tar_pc = np.copy(self.src_pc) # moving the target to src
        self.translateResult(T)
        self.publishResult()
        duration=rospy.Time.now()-time_0
        #print("time_cost: {} s".format(duration.to_sec()))
        pass

class LandmarkICP(ICPBase):
    def __init__(self):
        super(LandmarkICP,self).__init__()
    
    def laserCallback(self,msg):
        '''
        laser ICP odometry.
        '''
        time_0 = rospy.Time.now()
        self.src_pc = msg
        # print('input cnt: ',self.src_pc.shape[1])

        T=self.processICP(self.src_pc,self.tar_pc,initialT=np.identity(3))
        self.tar_pc = np.copy(self.src_pc) # moving the target to src
        self.translateResult(T)
        self.publishResult()
        duration=rospy.Time.now()-time_0
        #print("time_cost: {} s".format(duration.to_sec()))
        pass




def main():

    rospy.init_node('icp_node')

    icp = ICP()

    rospy.spin()



if __name__ == '__main__':

    main()
